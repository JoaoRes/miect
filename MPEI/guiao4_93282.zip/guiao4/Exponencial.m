function X = Exponencial(N,m)
U=rand(1,N);
X=-m*log(U);
end

