%% a

p=0,5;
N=10;
Y=bernoulli(p,N);
pS=sum(Y==1)/N

%% b

N=15;

floor(rand(1,N)*6)+1

%% c

N=20;
x=-4;
y=10;

C=(y-x)*rand(1,N)+x




