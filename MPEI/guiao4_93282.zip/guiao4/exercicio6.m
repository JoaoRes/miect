
hist(Exponencial (10000,0.5),20)