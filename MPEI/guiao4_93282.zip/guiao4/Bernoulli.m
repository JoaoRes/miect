function x = Bernoulli(p,N)
x=rand(1,N)<=p;
end

