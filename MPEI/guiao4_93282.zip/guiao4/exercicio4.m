N=1e6; 
n=20; 
p=0.3;
X=Binomial(n,p, N);
hist(X)